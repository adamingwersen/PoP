fsharpc -a image.fs && fsharpc -r image.dll 12i0.fsx && mono 12i0.exe

